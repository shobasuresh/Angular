import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-propertybinding-demo',
  templateUrl: './propertybinding-demo.component.html',
  styleUrls: ['./propertybinding-demo.component.css']
})
export class PropertybindingDemoComponent implements OnInit {


  
   value:number=1;
  isDisabled: boolean = true;
  title: string = 'Property Binding Demo and Switch Case Demo';

  

  constructor() { }

  ngOnInit(): void {
  }

}
