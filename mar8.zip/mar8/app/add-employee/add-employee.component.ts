import { Component, OnInit } from '@angular/core';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent implements OnInit {

  employee:Employee=new Employee();

   id:Object=0;
 
  successMessage=false;
  constructor(private employeeService:EmployeeService) { }

  addEmployee()
  {
  
   this.employeeService.addEmployee(this.employee).subscribe(data=>{
    console.log("data "+data);
     this.id=data;
    });
   
   }

    
   
    
  ngOnInit(): void {
  }


  onSubmit()
  {
    this.addEmployee();
    console.log(this.employee);
     
  }
}
