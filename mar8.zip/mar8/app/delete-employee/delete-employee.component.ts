import { Component, OnInit } from '@angular/core';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-delete-employee',
  templateUrl: './delete-employee.component.html',
  styleUrls: ['./delete-employee.component.css']
})
export class DeleteEmployeeComponent implements OnInit {

  id:number=0;
  
  error:string =" " ;
  employee:Employee=new Employee();
  
  constructor(private employeeService:EmployeeService,private route:ActivatedRoute) { }

  ngOnInit()  {
    this.id=this.route.snapshot.params['id']; 
    console.log("in init " +this.id);
    this.employeeService.getEmployeeById(this.id).subscribe(data=>{
           this.employee=data;
           console.log("getData "+data);
    });
  }

 deleteEmployee()
  {

   this.employeeService.deleteEmployee(this.id).subscribe(data=>{
    
          console.log("In up "+data);
  
          });
        }

        onSubmit() 
    {

       
      this.deleteEmployee();
       
    }
  }