import { Component, OnInit } from '@angular/core';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {

  employees: Employee[] = [];
  term!: string;
  constructor(private employeeService:EmployeeService,private router:Router) {
  }
 
  ngOnInit(): void {
  
    // this.getEmployee();
    this.employeeService.getEmployees().subscribe(data=>
      {
       console.log(data);
       this.employees=data;
        });
}


 

    updateEmployee(id:number)
   {

this.router.navigate(['/home/update-employee',id])

   }
  
   deleteEmployee(id:number)
   {

    this.router.navigate(['/home/delEmployee',id])
   }
  }