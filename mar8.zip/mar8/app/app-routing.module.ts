import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { EmployeeComponent } from './employee/employee.component';
import { EmployeeListComponent } from './employee-list/employee-list.component';
import { UpdateEmployeeComponent } from './update-employee/update-employee.component';
import { HomeComponent } from './home/home.component';
import { DeleteEmployeeComponent } from './delete-employee/delete-employee.component';
import { AddEmployeeComponent } from './add-employee/add-employee.component';

const routes: Routes = [
  // {path:'',redirectTo:'employees',pathMatch:"full"},
  {path:'home',component:HomeComponent,children:
    [
  {path:'employees',component:EmployeeComponent},
  {path:'employeeList',component:EmployeeListComponent},
  {path:'update-employee/:id',component:UpdateEmployeeComponent},
  {path:'delEmployee/:id',component:DeleteEmployeeComponent},
  {path:'addEmployee',component:AddEmployeeComponent},
] },

 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  
  exports: [RouterModule]
})
export class AppRoutingModule { }
