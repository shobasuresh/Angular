package com.pack;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringRestDemo4Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringRestDemo4Application.class, args);
	}

}
