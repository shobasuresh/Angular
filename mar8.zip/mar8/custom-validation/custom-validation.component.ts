import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-custom-validation',
  templateUrl: './custom-validation.component.html',
  styleUrls: ['./custom-validation.component.css']
})
export class CustomValidationComponent implements OnInit {

  form: FormGroup;
   
 
  constructor(private fb: FormBuilder) {
    this.form = this.fb.group({
      username: ['', [Validators.required, this.usernameValidator]]
    });
  }


  ngOnInit(): void {
   
  }

  // Custom validator function
  usernameValidator(control: any) {
    const value = control.value;
    if (value && value.includes('admin')) {
      return { 'usernameInvalid': true };  // Validation fails
    }
    return null;  // Validation passes
  }

  onSubmit() {
    if (this.form.valid) {
      console.log('Form Submitted:', this.form.value);
    } else {
      console.log('Form is invalid');
    }
  }
}
