var person1 = {
    name: "John",
    age: 25,
    isStudent: true,
    meth: function () {
        return this.isStudent;
    }
};
function greet(person) {
    console.log("Hello, ".concat(person.name, " Your age is  ").concat(person.age, " "));
    console.log("".concat(person.meth()));
}
greet(person1);
