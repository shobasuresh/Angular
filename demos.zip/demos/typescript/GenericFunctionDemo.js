function identity(arg) {
    return arg;
}
console.log(identity(5));
console.log(identity("hello"));
console.log(identity([1, 2, 3]));
function combine(a, b) {
    return "".concat(a, " and ").concat(b);
}
function concat1(a, b) {
    var st = "".concat(a).concat(b);
    return st;
}
console.log(combine(1, "apples"));
console.log(concat1("abc", "xyz"));
