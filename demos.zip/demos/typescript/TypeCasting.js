var someValue = "Hello, TypeScript!";
var strLength = someValue.length;
console.log(strLength);
