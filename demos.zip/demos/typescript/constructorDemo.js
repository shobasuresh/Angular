var Person = /** @class */ (function () {
    // Constructor method
    function Person(firstName, lastName, age) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
    }
    // A method in the class
    Person.prototype.greet = function () {
        console.log("Hello, my name is ".concat(this.firstName, " ").concat(this.lastName, " and I am ").concat(this.age, " years old."));
    };
    return Person;
}());
var person = new Person("Mariam", "Serah", 30);
person = { "jj": , "aa": , 67:  };
person.greet();
