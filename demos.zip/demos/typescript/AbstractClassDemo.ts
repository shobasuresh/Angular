// Abstract class
abstract class Animal {
    name: string;

    constructor(name: string) {
        this.name = name;
    }

    // Abstract method (must be implemented in derived classes)
    abstract speak(): void;

    move(): void {
        console.log(`${this.name} moves.`);
    }
}

// Derived class
class Dog extends Animal {
    constructor(name: string) {
        super(name);  // Call the parent class constructor
    }

    // Implement the abstract method
    speak(): void {
        console.log(`${this.name} barks.`);
    }
}

// You cannot instantiate an abstract class
// const animal = new Animal("Some Animal"); // Error: Cannot create an instance of an abstract class.

const dog = new Dog("Buddy");
dog.speak();  // Output: Buddy barks.
dog.move();   // Output: Buddy moves.