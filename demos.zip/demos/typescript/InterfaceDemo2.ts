interface Person {
  name: string;
  age: number;
  isStudent?: boolean; // optional property
}

class Employee implements Person {
  
  name: string;
  age: number;
  isStudent?: boolean;
    

  constructor(name: string, age: number, isStudent?: boolean) {
    this.name = name;
    this.age = age;
   
    if (isStudent !== undefined) this.isStudent = isStudent;
  }
}

let employee1 = new Employee("Bob", 40, false);
console.log(employee1);