import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-address-card',
  templateUrl: './address-card.component.html',
  styleUrls: ['./address-card.component.css']
})
export class AddressCardComponent implements OnInit {

  user:any;

  constructor() { 

    this.user=
    {
      cdate:new Date().toDateString(),
      name:"Reena",
      desig:"mgr",
      salary:5000,

      phone:
       [
         

       ]




    }


  }

  ngOnInit(): void {
  }

}
