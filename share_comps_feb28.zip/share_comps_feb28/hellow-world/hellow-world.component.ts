import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hellow-world',
  templateUrl: './hellow-world.component.html',
  styleUrls: ['./hellow-world.component.css']
})
export class HellowWorldComponent implements OnInit {
 
  message: string = '';

  // Method that gets called when the button is clicked
  clickMe(): void {
    this.message = 'Button was clicked!';
  }
      
  constructor() { }

  ngOnInit(): void {
  }

 

}
