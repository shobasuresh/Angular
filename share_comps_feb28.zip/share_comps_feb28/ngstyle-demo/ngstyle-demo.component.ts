import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ngstyle-demo',
  templateUrl: './ngstyle-demo.component.html',
  styleUrls: ['./ngstyle-demo.component.css']
})
export class NgstyleDemoComponent implements OnInit {

  backgroundColor = 'blue';
  fontSize = '20px';
  
  
  constructor() { }

  ngOnInit(): void {
  }

  styles = {
    'background-color': this.backgroundColor,
    'font-size': this.fontSize,
    
  };

   





}
